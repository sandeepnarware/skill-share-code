1. [Introduction to C#](#introduction)

2. [What is .NET ?](#what-is-net)

3. [Architecture of .NET Applications](#architecture-of-net-applications)

4. [Very First C# Application](#first-c-application)

5. [Fundamentals](./fundamentals/index.md)
   * [Identifiers](./fundamentals/index#identifiers)
   * [Variables and Constants](./fundamentals/index#variables)
   * [Data types](./fundamentals/datatypes)
   * [Operators](./fundamentals/operators)
   * [Loops](./fundamentals/loops)

6. [OOP's](./oops/index.md)
   * [Pillars of OOPS](./oops/index.md#four-pillars-of-oops)
   * [Encapsulation](./oops/index.md#1-encapsulation)
   * [Abstraction](./oops/index.md#2-abstraction)
   * [Inheritance](./oops/inheritance.md#3-inheritance)
   * [Polymorphism](./oops/inheritance.md#4-polymorphism)
   * [Class types](./oops/inheritance.md#Other-Class-types-in-C#)
   * [Interfaces](./oops/interfaces.md)
7. [Collections in C#](./oops/interfaces.md#collectons-in-c)
8. [LINQ](./oops/linq.md)
<br>
<br>

### *Session 1*
# Introduction

C# is a simple, modern, general-purpose, object-oriented **programming** language developed by Microsoft within its .NET initiative led by Anders Hejlsberg, it is pronounced as **“C sharp”**. 

C# can be used to create various types of applications, such as web, windows, console applications, or other types of applications using Visual studio.

C# programming is very much based on C and C++ programming languages, so if you have a basic understanding of C or C++ programming, then it will be fun to learn C#.

**Why C#?**

C# has many other reasons for being popular and in demand. Few of the reasons are mentioned below:

* **Easy to start**: C# is a high-level language so it is closer to other popular programming languages like C, C++, and Java and thus becomes easy to learn for anyone.

* **Widely used for developing Desktop and Web Application**: C# is widely used for developing web applications and Desktop applications. It is one of the most popular languages that is used in professional desktop. If anyone wants to create Microsoft apps, C# is their first choice.

* **Community**: The larger the community the better it is as new tools and software will be developing to make it better. C# has a large community so the developments are done to make it exist in the system and not become extinct.

* **Game Development**: C# is widely used in game development and will continue to dominate. C# integrates with Microsoft and thus has a large target audience. The C# features such as Automatic Garbage Collection, interfaces, object-oriented, etc. make C# a popular game developing language. **Unity** is a most popular game development framework based on the language **C#**.

C# was first introduced with .NET Framework 1.0 in the year 2002 and evolved much since then.

<br>

# What is .NET ?

.NET is a free, open-source **development platform** for building many kinds of application such as Web applications, Web API's, Microservices, Mobile applications, Dekstop applications, Game development, Internet of Things, Machine learning etc.

There is a variety of programming languages available on the .NET platform, `VB.NET` and `C#` being the most common ones.

.NET Framework supports more than **60** programming languages in which **11** programming languages are *designed and developed* by **Microsoft**. The remaining Non-Microsoft Languages are supported by .NET Framework but not designed and developed by Microsoft. 

The **11** Programming Languages which are designed and developed by Microsoft are: 

* C#.NET
* VB.NET
* C++.NET
* J#.NET
* F#.NET
* JSCRIPT.NET
* WINDOWS POWERSHELL
* IRON RUBY
* IRON PYTHON
* C OMEGA
* ASML(Abstract State Machine Language)

<br>

# Architecture of .NET Applications

The architecture of .Net framework is based on the following key components;

1. **Common Language Runtime**
The “Common Language Infrastructure” or CLI is a platform in .Net architecture on which the .Net programs are executed.

    The CLI has the following key features:

    **Exception Handling** – Exceptions are errors which occur when the application is executed.

    Examples of exceptions are:

    If an application tries to open a file on the local machine, but the file is not present.

    If the application tries to fetch some records from a database, but the connection to the database is not valid.


    **Garbage Collection** – Garbage collection is the process of removing unwanted resources when they are no longer required.

    Examples of garbage collection are

    A File handle which is no longer required. If the application has finished all operations on a file, then the file handle may no longer be required.

    The database connection is no longer required. If the application has finished all operations on a database, then the database connection may no longer be required.

2. **Class Library**
    The .NET Framework includes a set of standard class libraries. A class library is a collection of methods and functions that can be used for the core purpose.

    For example, there is a class library with methods to handle all file-level operations. So there is a method which can be used to read the text from a file. Similarly, there is a method to write text to a file.

3. **Languages**

    The types of applications that can be built in the .Net framework is classified broadly into the following categories.

    **WinForms** – This is used for developing Forms-based applications, which would run on an end user machine. Notepad is an example of a client-based application.

    **ASP.Net** – This is used for developing web-based applications, which are made to run on any browser such as Internet Explorer, Chrome or Firefox.

    **ADO.Net** – This technology is used to develop applications to interact with Databases such as Oracle or Microsoft SQL Server.

<br>

# First C# Application

Here, you will learn to create a simple console application in C# and understand the basic building blocks of a console application.

C# can be used in a window-based, web-based, or console application. To start with, we will create a console application to work with C#.

## Visual Studio - The IDE

![alt](images/visual-studio-2013-logo.png)

Visual studio is a developer friendly, feature-rich program that supports many aspects of software development. The Visual Studio IDE is a creative launching pad that you can use to edit, debug, and build code, and then publish an app.

Over and above the standard editor and debugger that most IDEs provide, Visual Studio includes compilers, code completion tools, graphical designers, and many more features to enhance the software development process.

You can download and install a free and latest community version of visual studio here: https://visualstudio.microsoft.com/vs/community/

### Create new project

Open Visual Studio installed on your local machine. Click on File -> New -> Project from the top menu, as shown below.

![alt](images/create-project-in-visualstudio.png)

From the New Project popup, shown below, select Visual C# in the left side panel and select the Console App in the right-side panel.

![alt](images/create-csharp-console-project.png)

In the name section, give any appropriate project name, a location where you want to create all the project files, and the name of the project solution.

Click OK to create the console project. Program.cs will be created as default a C# file in Visual Studio where you can write your C# code in Program class, as shown below. (The .cs is a file extension for C# file.)

![alt](images/csharp-program.png)

Every console application starts from the Main() method of the Program class. The following example displays "Hello World!!" on the console.

```c#
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkillHouseCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            string message = "Hello World!!";

            Console.WriteLine(message);
        }
    }
}
```

Let's understand the above C# structure.

1. Every .NET application takes the reference of the necessary .NET framework namespaces that it is planning to use with the `using` keyword, e.g., `using System.Text`.
2. Declare the namespace for the current class using the `namespace` keyword, e.g., namespace `SkillHouseCSharp`
3. We then declared a class using the `class` keyword: `class Program`
4. The `Main()` is a method of Program class is the entry point of the console application.
5. `String` is a data type.
6. A `message` is a variable that holds the value of a specified data type.
7. "Hello World!!" is the value of the message variable.
8. The `Console.WriteLine()` is a static method, which is used to display a text on the console.

## Compile and Run C# Program
To see the output of the above C# program, we have to compile it and run it by pressing Ctrl + F5 or clicking the Run button or by clicking the "Debug" menu and clicking "Start Without Debugging".

## .NET Fiddle

![alt](images/dotnet-fiddle.jpg)

If you want to try C# editor online quickly without opening Visual Studio, you can try .NET Fiddle tool which provides an environment to directly write some C# code and execute them on your browser.

https://dotnetfiddle.net/

## :white_check_mark: Tasks
:white_check_mark: Create a new Console application in Visual Studio and language as C# and write a program to print `Hello Skillhouse!`.

### *End of session 1*

<br>


### [NEXT - Fundamentals](./fundamentals/index.md)